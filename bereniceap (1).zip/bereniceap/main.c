#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

#include "funcao.h"

int main(int argc, char *argv[]){

    //argc � � um valor inteiro que indica a quantidade de argumentos que foram passados ao chamar o programa.

    /*argv[] armazena o nome do programa que foi chamado no prompt, sendo assim, argc � pelo menos igual a 1, pois no m�nimo existir� um argumento.

    Os argumentos passados por linha de comando devem ser separados por um espa�o ou tabula��o

    Inicio do programa: Vari�veis, Lista de produtos:*/
    setlocale(LC_ALL, "Portuguese"); //  permite a inser��o de acentos e caract�res especiais em portugu�s
	int opCod;//salva a opcao no primeiro switch
	char menu;//opcao que reinicia o loop do menu ou sai do programa

	do
	{
		system("cls");
		printf("----------------------------------------\n");
        printf("         Mercado da Berenice        \n");
        printf("----------------------------------------\n");
		printf("Cadastrar Estoque                     1\n");
		printf("Visualizar Estoque                    2\n");
		printf("Realizar Venda                        3\n");
		printf("Sair                                  4\n");
		printf("----------------------------------------\n");
		printf("Selecione uma op��o                  :");
		scanf("%i", &opCod);
		getchar();

		if(opCod > 0 && opCod < 4)
		{
			switch(opCod)
			{
				case 1:
					printf("CADASTRAR ESTOQUE\t\t\t|\n");

					cadastrar_estoque();

					scanf("%c", &menu);
					break;

				case 2:
					printf("VISUALIZAR ESTOQUE\t\t\t|\n");
					visualizar_estoque();

					printf("PRESSIONE ENTER PARA VOLTAR AO MENU\nQUALQUER TECLA PARA SAIR             |");
					scanf("%c", &menu);
					break;

				case 3:
					realizar_venda();

					printf("PRESSIONE ENTER PARA VOLTAR AO MENU\nQUALQUER TECLA PARA SAIR             |");//reinicia o loop ou sai do programa
					scanf("%c", &menu);
					break;
			}
		}

		else if(opCod == 4)//se o codigo 4 sair for acionado, sai do loop e do programa
		{
			break;
		}

		else//caso a opcao for invalida, pergunta se o usuario quer voltar ao menu ou sair
		{
			printf("OPCAO INVALIDA!\t\t\t\t|\n");
			printf("PRESSIONE ENTER PARA VOLTAR AO MENU\t|\nQUALQUER TECLA PARA SAIR\t\t|");//reinicia o loop ou sai do programa
			scanf("%c", &menu);
		}
	}while(menu == '\n');

	return 0;
}
