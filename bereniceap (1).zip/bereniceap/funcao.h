#ifndef FUNCAO_H_INCLUDED
#define FUNCAO_H_INCLUDED

#define TAM 5;
    typedef struct{
        int cod; //codigo do produto
        char nome[50]; //nome do produto
        float preco; //pre�o do produto
        int estoque; //estoque cadastado
        int quantidade; // quantidade desejada pelo cliente

    }Produto;




    extern Produto produtos[]; //variavel global

    //fun��es do programa
void cadastrar_estoque();

void visualizar_estoque();

void realizar_venda();

void forma_pagamento(float);

#endif // FUNCAO_H_INCLUDED
