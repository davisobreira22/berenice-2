#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

#include "funcao.h"

Produto produtos [5] =
{
    {1, "PAO DE FORMA", 7.50, 0, 0},
    {2, "PAO DE CENTEIO", 8.69, 0, 0},
    {3, "BROA DE MILHO", 5, 0, 0},
    {4, "SONHO\t", 4.50, 0, 0},
    {5, "TUBAINA", 3.25, 0, 0}
};

void cadastrar_estoque()
{

    char menu_estoque;
    do
    {
        system("cls"); //limpar a tela
        int cod;


        printf("          Cadastrar Estoque          \n");
        printf("Cod: 1                            P�o de Forma\n");
        printf("Cod: 2                            P�o de Centeio\n");
        printf("Cod: 3                            Broa de Milho\n");
        printf("Cod: 4                            Sonho\n");
        printf("Cod: 5                            Tuba�na\n");

        printf("\n DIGITE O C�DIGO DO PRODUTO        Cod: ");
        scanf("%i", &cod);
        getchar();

        if(cod > 0 && cod < 6)
        {
            printf("DIGITE A QUANTIDADE DISPONIVEL         ");
            scanf("%i", &produtos[cod - 1].estoque);
            getchar();

            if(produtos[cod - 1].estoque > 0) //cod - 1 � para os itens, ele vai passando at� achar o veradeiro que �
                //o digitado pelo usuario, funciona como um contador
            {
                printf("\nAdicionado %i unidades para %s",produtos[cod - 1].estoque, produtos[cod - 1].nome);
                printf("\n");
                printf("\n'ENTER' PARA CADASTRAR OUTRO PRODUTO\n");
                printf("'N' PARA VOLTAR AO MENU                ");
                scanf("%c", &menu_estoque);
            }

            else
            {
                printf("\nQUANTIDADE INVALIDA!\n");
                printf("'ENTER' PARA TENTAR OUTRA QUANTIDADE\t|\n");
                printf("'N' PARA VOLTAR AO MENU\t\t|\n");
                scanf("%c", &menu_estoque);
            }
        }

        else
        {
            printf("CODIGO INVALIDO!\n");
            printf("'ENTER' PARA OUTRO CODIGO\t\t|\n");
            printf("'N' PARA VOLTAR AO MENU\t\t\t|\n");
            scanf("%c", &menu_estoque);
        }

    }
    while(menu_estoque == '\n');  //o /n � o enter do codigo


}

void visualizar_estoque()
{
    //char //menu_estoque2;
    system("cls"); //limpar a tela
    int i;
    printf("           Visualizar Estoque         \n");
    printf("CODIGO\tPRODUTO\t\tVALOR\t ESTOQUE\n");
    for(i = 0; i < 5; i++)
    {
        //aqui vizualiza o estoque
          printf("%i \t %s\t  %.2f\t     |%i\n", produtos[i].cod, produtos[i].nome, produtos[i].preco, produtos[i].estoque);

     }

    }



void realizar_venda()
{
    int i, j, q_item, cod, contador = 0;//quantidade para a venda
    char menu_estoque, menu_estoque2; // menu de estoque2 aparece na linha 137
    Produto vendido[1000];//o limite de produtos vendidos � 1000
    float subtotal = 0;


    do
    {

        visualizar_estoque();
        printf("\nDIGITE O CODIGO DO PRODUTO\t     |");

        scanf("%i", &cod);
        getchar();

        if(cod > 0 && cod < 6)
        {
            printf("DIGITE A QUANTIDADE DO ITEM\t     |");
            scanf("%i", &q_item);
            getchar();

            if(q_item > 0)
            {
                if(q_item <= produtos[cod-1].estoque) //bubblesort

                    /*O algoritmo bubblesort funciona, de forma simplificada, executando duas tarefas principais,
                     que s�o executadas em loop at� que os dados estejam totalmente ordenados (classificados).*/

                {
                    contador++;

                    produtos[cod-1].estoque = produtos[cod-1].estoque - q_item; //aqui a quantidade do produto diminui no estoque

                    vendido[contador-1] = produtos[cod-1]; //aqui o produto selecionado ganha o nome de vendido pq iremos vende-lo

                    vendido[contador-1].quantidade = q_item; //a quantidade � igual ao quantidade no item

                    vendido[contador-1].preco = produtos[cod-1].preco * q_item;//o calculo � pre�o x a quantidade do item informado

                    subtotal = subtotal + vendido[contador - 1].preco; //o subtotal � o calculo basicamente

                    printf("\nSub-Total da Venda: R$ %.2f\n", subtotal);

                    printf("\n'T' PARA VENDER OUTRO PRODUTO\n'S' PARA VER RELATORIO DA VENDA\t     |");

                    scanf("%c", &menu_estoque2);
                    getchar();

                    for(i = 0; i < contador; i++) //contador se revere a quantidade s� pra lembrar
                    {
                        for(j = 0; j < contador; j++)
                        {
                            if(vendido[i].preco > vendido[j].preco)
                            {
                                Produto tmp;
                                tmp = vendido[i]; //vendido se torna tmp
                                vendido[i] = vendido[j];
                                vendido[j] = tmp;
                            }
                        }
                    }

                    if(menu_estoque2 == 's' || menu_estoque2 == 'S') //s relatorio de venda
                    {
                        system("cls");
                        for(i = 0; i < contador; i++)
                        {

                            if(vendido[i].cod == 4 || vendido[i].cod == 5)
                            {
                                printf("%s\t\t\tUNIDADES  |%i\t|%.2f\n", vendido[i].nome, vendido[i].quantidade, vendido[i].preco);
                            }
                            else
                            {
                                printf("          Relatorio de Vendas         \n"); //relatorios dos itens vendidos
                                printf("%s\t\tUNIDADES  |%i\t|%.2f\n", vendido[i].nome, vendido[i].quantidade, vendido[i].preco);

                            }
                        }
                        forma_pagamento(subtotal); //fun��o implementada: uma fun��o dentro de uma fun��o

                        menu_estoque = 1;
                    }

                    else if(menu_estoque2 == 'T' || menu_estoque2 == 't') //para vender outro produto
                    {
                        menu_estoque = '\n';
                    }

                }
                else
                {
                    printf("\nQUANTIDADE INVALIDA!\n");
                    printf("'ENTER' PARA TENTAR OUTRA QUANTIDADE |\n");
                    printf("'N' PARA VOLTAR AO MENU              |\n");
                    scanf("%c", &menu_estoque);
                }
            }

        }
        else
        {
            printf("CODIGO INVALIDO!\n");
            printf("'ENTER' PARA OUTRO CODIGO\t\t|\n");
            printf("'N' PARA VOLTAR AO MENU\t\t\t|\n");
            scanf("%c", &menu_estoque);
        }

    }
    while(menu_estoque == '\n');

}

void forma_pagamento(float sub_total)
{

    int  parcelas, opcao_pagamento;
    float   valor_pago, valor_desconto, valor_acrescimo, troco, valor_recebido,valor_parcela; //variaveis que possuem numeros decimais
    printf("%.2f", sub_total);
    printf("\n Opcoes de pagamento:\n");
    printf("\n 1. A vista com desconto \n");
    printf("\n 2. A prazo \n");
    printf("\n Digite a opcao de pagamento desejada: \n ");
    scanf("%d", &opcao_pagamento);
    getchar();
    if (opcao_pagamento <=0 || opcao_pagamento >= 3)
    {
        printf("\n Opcao de pagamento invalida \n"); // caso a opcao selecionada for menor que 0 ou maior que 3, aparecera no display a seguinte mensagem dita anteriormente
    }

    switch(opcao_pagamento)   // o calculo realizado na opcao avista, calcular o desconto
    {
    case 1: //opcao avista
        if (sub_total > 0 && sub_total <= 50.0 )
        {
            valor_desconto = sub_total * 0.05;// 100/5= 0.05 total de 5% de desconto;
        }
        else if (sub_total > 50 && sub_total< 100.0)
        {
            valor_desconto = sub_total * 0.1; // se for maior que 50 reias ou menor que 100 reais, o desconto sera de 10%
        }
        else
        {
            valor_desconto = sub_total * 0.18; // se for acima de 100 reais, sera 18 % de desconto
        }
        valor_pago = sub_total - valor_desconto; // formula do valor pago

        printf("\n Valor a ser pago: R$ %.2f\n", valor_pago); //mostra no display o valor a ser pago
        printf("\n Digite o valor recebido: \n ");
        scanf("%f", &valor_recebido);
        getchar();
        printf("\n Valor Recebido: %.2f\n", valor_recebido);

        if ( valor_recebido >= sub_total)  // IF PARA DIZER SE O VALOR DE TROCO ESTA CERTO
        {

            troco = (valor_recebido - sub_total); //formula do troco


            printf("\n Troco: R$ %.2f \n", troco);

        }

        else  //(valor_recebido  < sub_total) ;// ELSE PARA CASO O VALOR DADO SEJA MENOR PARA NAO HAVER PREJUIZO
        {

            printf("\n valor invalido \n");
        }


        break;
    case 2: //calculo da opcao a prazo, calculo dos acrescimos
        printf("\n Digite o numero de parcelas (ate 10): \n ");
        scanf("%d", &parcelas);
        getchar();

        if (parcelas <= 3)
        {
            valor_acrescimo = sub_total * 0.05;//se for at� 3 parcelas � para ter um acr�scimo de 5% ou 5/100= 0.05
        }
        else
        {
            valor_acrescimo = sub_total * 0.08;// se for maior que 3 parcelas � para ter um acr�scimo de 8% ou 8/100= 0.08
        }
        if (parcelas <=0 || parcelas >= 10)
        {
            printf("\n Opcao selecionada invalida \n"); // caso o numero de parcelas seja menor ou igual a 0 ou maior e igual 11, opcao sera invalida

            //exit (0);
        }

        valor_pago = sub_total + valor_acrescimo; //formula do acrescimo

        printf("Valor a ser pago: R$ %.2f\n", valor_pago);
        valor_parcela = sub_total / parcelas;
        printf("\n Valor da parcela= %.2f \n",valor_parcela);
        break;

        //exit(0);

    }
}
